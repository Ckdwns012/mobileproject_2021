package com.jshan.mobileproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class sickActivity extends AppCompatActivity {
    TextView diseasetext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sick1);

        diseasetext=findViewById(R.id.diseasetext);
        Intent intent =getIntent();
        Bundle bundle1 = intent.getExtras();
        Bundle bundle2 = intent.getExtras();
        Bundle bundle3 = intent.getExtras();
        Bundle bundle4 = intent.getExtras();
        Bundle bundle5 = intent.getExtras();
        String str1= bundle1.getString("sick1");
        if (str1==null){
            str1="";
        }
        String str2= bundle2.getString("sick2");
        if (str2==null){
            str2="";
        }
        String str3= bundle3.getString("sick3");
        if (str3==null){
            str3="";
        }
        String str4= bundle4.getString("sick4");
        if (str4==null){
            str4="";
        }
        String str5= bundle5.getString("sick5");
        if (str5==null){
            str5="";
        }
        String sick = str1+str2+str3+str4+str5;
        diseasetext.setText(sick);

    }
}