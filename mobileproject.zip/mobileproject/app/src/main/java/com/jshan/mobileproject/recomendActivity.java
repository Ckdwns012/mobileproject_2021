package com.jshan.mobileproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;


public class recomendActivity extends AppCompatActivity {
    int[] img = {R.drawable.kongnamul, R.drawable.hamburger, R.drawable.coffee, R.drawable.ramen, R.drawable.myen,R.drawable.jambong,R.drawable.bbu,R.drawable.soon};
    String[] recomendarray=new String[]{"콩나물국밥","햄버거","커피","라면","냉면","짬뽕","뼈해장국","순대국"};
    Random ram = new Random();
    int num = ram.nextInt(img.length);
    ImageButton randomchoice;
    ImageButton okay;
    ImageView randomimage;
    TextView recomend;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recomend);

        randomchoice=findViewById(R.id.randomchoice);
        okay=findViewById(R.id.okay);
        randomimage=findViewById(R.id.randomimage);
        recomend=findViewById(R.id.recomend);

        randomchoice.setClickable(true);
        randomchoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num = ram.nextInt(img.length);
                randomimage.setBackgroundResource(img[num]);
                recomend.setText(recomendarray[num]);
            }
        });
        okay.setClickable(true);
        okay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(recomendActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });

        //randomimage.setBackgroundResource(img[num]);

    }
}