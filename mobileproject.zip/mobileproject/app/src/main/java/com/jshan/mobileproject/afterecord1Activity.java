package com.jshan.mobileproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class afterecord1Activity extends AppCompatActivity {
    ImageButton plus1;
    EditText input_soju,input_beer,input_wine,input_whiskey;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.afterrecord1);

        input_soju=findViewById(R.id.count1);
        input_beer=findViewById(R.id.count2);
        input_wine=findViewById(R.id.count3);
        input_whiskey=findViewById(R.id.count4);

        plus1=findViewById(R.id.plus1);

        plus1.setClickable(true);
        plus1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String soju = input_soju.getText().toString();
                String whiskey = input_whiskey.getText().toString();
                String beer = input_beer.getText().toString();
                String wine = input_wine.getText().toString();

                Intent intent = new Intent(afterecord1Activity.this, savedataActivity.class);
                intent.putExtra("soju",soju);
                intent.putExtra("beer",beer);
                intent.putExtra("wine",wine);
                intent.putExtra("whiskey",whiskey);
                startActivity(intent);
            }
        });


    }
}