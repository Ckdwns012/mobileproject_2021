package com.jshan.mobileproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;


public class MainActivity extends AppCompatActivity {
    ImageButton main_recording;
    ImageButton main_result;
    ImageButton main_choice;
    ImageButton main_sick;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        main_recording=findViewById(R.id.main_recording);
        main_recording.setClickable(true);
        main_recording.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(MainActivity.this,afterecord1Activity.class);
                startActivity(intent);
            }
        });
        main_result=findViewById(R.id.main_result);
        main_result.setClickable(true);
        main_result.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(MainActivity.this,savedataActivity.class);
                startActivity(intent);
            }
        });
        main_choice=findViewById(R.id.main_choice);
        main_choice.setClickable(true);
        main_choice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(MainActivity.this,recomendActivity.class);
                startActivity(intent);
            }
        });
        main_sick=findViewById(R.id.main_sick);
        main_sick.setClickable(true);
        main_sick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(MainActivity.this,ifsickActivity.class);
                startActivity(intent);
            }
        });

    }
}